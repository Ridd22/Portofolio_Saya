# Portofolio — Farid Agatha Pratama

Website portofolio profesional untuk menampilkan profil, keahlian, dan proyek-proyek yang pernah dikerjakan.

## 🚀 Cara Menjalankan

### Metode 1: Langsung via Browser
1. Buka folder `Portfolio_Saya`
2. Klik dua kali pada file `index.html`
3. Website akan terbuka di browser default Anda

### Metode 2: Visual Studio Code + Live Server (Disarankan)
1. Buka **Visual Studio Code**
2. Install extension **Live Server** oleh Ritwick Dey (jika belum):
   - Tekan `Ctrl + Shift + X` untuk membuka Extensions
   - Cari "Live Server"
   - Klik **Install**
3. Buka folder `Portfolio_Saya` di VS Code:
   - **File** → **Open Folder** → pilih folder `Portfolio_Saya`
4. Klik kanan pada file `index.html`
5. Pilih **Open with Live Server**
6. Website akan terbuka di browser pada `http://127.0.0.1:5500`

## 📁 Struktur Folder

```
Portfolio_Saya/
├── index.html          # Halaman utama
├── css/
│   └── style.css       # Stylesheet
├── js/
│   └── script.js       # JavaScript interaktivitas
├── assets/
│   ├── images/         # Gambar (foto profil, screenshot proyek)
│   └── icons/          # Ikon tambahan
└── README.md           # Dokumentasi
```

## 🖼️ Mengganti Foto Profil

1. Siapkan foto profil Anda (format `.jpg`, `.png`, atau `.webp`)
2. Simpan foto ke folder `assets/images/` dengan nama `foto-profil.jpg`
3. Buka file `index.html`
4. Cari bagian **Hero Section** (sekitar baris yang bertuliskan "Placeholder photo")
5. **Hapus** atau **comment** elemen `<div class="hero__photo-placeholder">...</div>`
6. **Uncomment** baris `<img>` yang ada di bawahnya:
   ```html
   <img src="assets/images/foto-profil.jpg" alt="Foto Farid Agatha Pratama" class="hero__photo" width="380" height="440" loading="eager">
   ```
7. Sesuaikan nama file jika berbeda

## 📧 Mengganti Email

Cari dan ganti semua `email@example.com` di file berikut:
- `index.html` — pada bagian Hero (mailto link) dan Kontak
- `js/script.js` — pada variabel `mailtoEmail` di fungsi validasi form

## 🔗 Mengganti Link GitHub

Cari dan ganti `https://github.com/` di file `index.html`:
- Pada bagian Hero socials
- Pada bagian Kontak

Contoh: `https://github.com/faridagatha`

## 🔗 Mengganti Link LinkedIn

Cari dan ganti `https://linkedin.com/` di file `index.html`:
- Pada bagian Hero socials

Contoh: `https://linkedin.com/in/faridagatha`

## 🖼️ Menambahkan Screenshot Proyek

1. Siapkan screenshot proyek (rasio 16:9 disarankan, minimal 600x400px)
2. Simpan ke folder `assets/images/` dengan format:
   - `project-eticketing.jpg`
   - `project-dashboard.jpg`
   - `project-mangga.jpg`
   - `project-perpustakaan.jpg`
   - `project-angkasa.jpg`
   - `project-greenova.jpg`
   - `project-eventmini.jpg`
3. Di `index.html`, cari project card yang ingin diubah
4. Ganti `<div class="thumb-placeholder">...</div>` dengan:
   ```html
   <img src="assets/images/project-eticketing.jpg" alt="Screenshot Sistem E-Ticketing" loading="lazy" width="600" height="400" style="width:100%;height:100%;object-fit:cover;">
   ```

## 🔧 Menambahkan Link Repository Proyek

1. Buka file `js/script.js`
2. Cari objek `projectData`
3. Ubah `repoUrl: null` menjadi URL repository Anda:
   ```javascript
   repoUrl: 'https://github.com/username/nama-repo',
   ```
4. Untuk menambahkan link demo, ubah `demoUrl: null`:
   ```javascript
   demoUrl: 'https://username.github.io/nama-repo',
   ```

## 🛠️ Teknologi

- **HTML5** — Struktur semantik
- **CSS3** — Styling modern dengan CSS Variables, Flexbox, Grid, dan Media Queries
- **JavaScript (ES6+)** — Interaktivitas tanpa framework

## 📱 Fitur Responsif

Website ini responsif dan dapat ditampilkan dengan baik di:
- 💻 Desktop (1200px+)
- 📱 Tablet (768px - 1024px)
- 📱 Smartphone (< 768px)

## ✨ Fitur Interaktif

- Navigasi sticky dengan indikator aktif
- Hamburger menu pada perangkat mobile
- Smooth scrolling
- Filter kategori proyek
- Modal detail proyek
- Animasi scroll reveal
- Validasi formulir kontak
- Tombol kembali ke atas
- Tahun copyright otomatis
- Dukungan keyboard (Escape untuk menutup modal)
- Aksesibilitas dasar (ARIA labels, semantic HTML)

## 📝 Catatan

- Website ini menggunakan HTML, CSS, dan JavaScript murni tanpa framework.
- Formulir kontak menggunakan `mailto:` karena tidak ada backend.
- Font dimuat dari Google Fonts (memerlukan koneksi internet).
- Semua path menggunakan path relatif agar portable.

---

© 2026 Farid Agatha Pratama
