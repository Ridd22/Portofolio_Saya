/* =============================================
   PORTFOLIO WEBSITE - FARID AGATHA PRATAMA
   Vanilla JavaScript - Interactive Features
   ============================================= */

'use strict';

// ===== PROJECT DATA =====
const projectData = {
    eticketing: {
        title: 'Sistem E-Ticketing Wisata Pantai',
        category: 'Web Development',
        badge: 'badge--web',
        badgeText: 'Web',
        description: 'Sistem tiket wisata berbasis website untuk membantu pengelolaan data pengunjung dan transaksi tiket secara digital. Proyek ini dirancang sebagai solusi digitalisasi proses pembelian tiket yang sebelumnya dilakukan secara manual. Fitur yang dikembangkan mencakup pengelolaan data pengunjung, pencatatan transaksi, dan tampilan antarmuka yang user-friendly.',
        tech: ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS'],
        status: 'Proyek Akademik — Dalam pengembangan. Beberapa fitur masih dalam tahap implementasi dan perlu diuji lebih lanjut.',
        role: 'Pengembang utama (proyek akademik)',
        repoUrl: null,
        demoUrl: null
    },
    dashboard: {
        title: 'Dashboard Admin (Vue.js)',
        category: 'Web Development',
        badge: 'badge--web',
        badgeText: 'Web',
        description: 'Pembaruan fitur dashboard administrasi yang mencakup pengelolaan status produk dengan tombol hapus, halaman pelanggan, sistem routing menggunakan Vue Router, dan penyimpanan daftar produk menggunakan LocalStorage. Dashboard ini dirancang untuk membantu admin dalam mengelola data produk dan pelanggan secara efisien.',
        tech: ['Vue.js', 'Vue Router', 'Bootstrap', 'LocalStorage', 'JavaScript'],
        status: 'Proyek Akademik — Pembaruan fitur telah dikembangkan. Beberapa fitur masih perlu pengujian lebih lanjut.',
        role: 'Pengembang (proyek akademik / pembaruan fitur)',
        repoUrl: null,
        demoUrl: null
    },
    mangga: {
        title: 'Analisis Segmentasi Daerah Penghasil Mangga',
        category: 'Data Analytics',
        badge: 'badge--data',
        badgeText: 'Data',
        description: 'Proyek data mining untuk mengelompokkan daerah penghasil mangga di Indonesia berdasarkan variabel produksi, jumlah desa penghasil, dan jumlah kecamatan. Proyek ini menggunakan dataset sekitar 6.497 baris dan mencakup pemeriksaan missing value, preprocessing data, pemilihan fitur, serta penerapan algoritma K-Means Clustering untuk menghasilkan segmentasi yang bermakna.',
        tech: ['Python', 'Pandas', 'Google Colab', 'K-Means Clustering'],
        status: 'Proyek Akademik — Analisis telah dilakukan. Hasil clustering dan visualisasi tersedia sebagai bagian dari laporan proyek.',
        role: 'Analis data (proyek akademik)',
        repoUrl: null,
        demoUrl: null
    },
    perpustakaan: {
        title: 'Sistem Informasi Perpustakaan',
        category: 'Web Development',
        badge: 'badge--web',
        badgeText: 'Web',
        description: 'Website administrasi perpustakaan untuk pengelolaan data buku, kategori buku, dan data anggota perpustakaan. Sistem ini dirancang untuk memudahkan pengelolaan inventaris buku dan pencatatan data peminjam secara digital.',
        tech: ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS'],
        status: 'Proyek Akademik — Fitur dasar telah dikembangkan.',
        role: 'Pengembang (proyek akademik)',
        repoUrl: null,
        demoUrl: null
    },
    angkasa: {
        title: 'Angkasa Fishing Tackle',
        category: 'Mobile Development',
        badge: 'badge--mobile',
        badgeText: 'Mobile',
        description: 'Proyek adaptasi aplikasi toko menjadi aplikasi katalog peralatan pancing berbasis mobile. Aplikasi ini mengimplementasikan konsep keranjang belanja untuk pengguna serta fitur pengelolaan produk oleh admin. Dikembangkan menggunakan framework Flutter dengan bahasa Dart.',
        tech: ['Flutter', 'Dart'],
        status: 'Proyek Akademik — Implementasi perlu diuji kembali. Belum siap untuk tahap produksi.',
        role: 'Pengembang (proyek akademik)',
        repoUrl: null,
        demoUrl: null
    },
    greenova: {
        title: 'Greenova',
        category: 'Konsep Bisnis / UI/UX',
        badge: 'badge--konsep',
        badgeText: 'Konsep',
        description: 'Ide website bertema lingkungan yang pernah dieksplorasi untuk konteks kompetisi. Konsep ini mencakup eksplorasi desain antarmuka dan perencanaan fitur yang mendukung kesadaran lingkungan. Detail fitur final dan implementasi teknis masih perlu dikonfirmasi.',
        tech: ['UI/UX', 'Konsep Desain'],
        status: 'Ide / Konsep — Belum diimplementasikan sebagai produk final.',
        role: 'Pemrakarsa ide / Kontributor konsep',
        repoUrl: null,
        demoUrl: null
    },
    eventmini: {
        title: 'EventMini',
        category: 'Konsep Bisnis / UI/UX',
        badge: 'badge--konsep',
        badgeText: 'Konsep',
        description: 'Ide layanan digital untuk membantu penyelenggara acara kecil dalam mengelola pendaftaran peserta, tiket digital, check-in, dan informasi acara. Konsep ini dirancang untuk menyederhanakan proses manajemen acara berskala kecil hingga menengah.',
        tech: ['UI/UX', 'Konsep Bisnis'],
        status: 'Ide Bisnis / Konsep — Belum dikembangkan menjadi aplikasi.',
        role: 'Pemrakarsa ide / Perencana konsep',
        repoUrl: null,
        demoUrl: null
    }
};

// ===== DOM ELEMENTS =====
const navbar = document.getElementById('navbar');
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.navbar__link');
const filterBtns = document.querySelectorAll('.filter-btn');
const projectCards = document.querySelectorAll('.project-card');
const detailBtns = document.querySelectorAll('.btn--detail');
const modalOverlay = document.getElementById('projectModal');
const modalClose = document.getElementById('modalClose');
const backToTop = document.getElementById('backToTop');
const contactForm = document.getElementById('contactForm');
const footerYear = document.getElementById('footerYear');

// ===== FOOTER YEAR =====
if (footerYear) {
    footerYear.textContent = new Date().getFullYear();
}

// ===== NAVBAR SCROLL EFFECT =====
function handleNavbarScroll() {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
}

window.addEventListener('scroll', handleNavbarScroll);

// ===== HAMBURGER MENU =====
navToggle.addEventListener('click', () => {
    const isActive = navToggle.classList.toggle('active');
    navMenu.classList.toggle('active');
    navToggle.setAttribute('aria-expanded', isActive.toString());
    document.body.style.overflow = isActive ? 'hidden' : '';
});

// Close menu when clicking a link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    });
});

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }
});

// ===== ACTIVE NAV LINK ON SCROLL =====
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const scrollPos = window.scrollY + 150;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');

        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('data-section') === sectionId) {
                    link.classList.add('active');
                }
            });
        }
    });
}

window.addEventListener('scroll', updateActiveNavLink);

// ===== PROJECT FILTER =====
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Update active filter button
        filterBtns.forEach(b => {
            b.classList.remove('active');
            b.setAttribute('aria-selected', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');

        const filter = btn.getAttribute('data-filter');

        // Filter projects
        projectCards.forEach(card => {
            const category = card.getAttribute('data-category');
            if (filter === 'semua' || category === filter) {
                card.classList.remove('hidden');
                card.style.animation = 'fadeInUp 0.4s ease forwards';
            } else {
                card.classList.add('hidden');
                card.style.animation = '';
            }
        });
    });
});

// ===== PROJECT MODAL =====
function openModal(projectKey) {
    const project = projectData[projectKey];
    if (!project) return;

    document.getElementById('modalTitle').textContent = project.title;
    document.getElementById('modalDesc').textContent = project.description;
    document.getElementById('modalStatus').textContent = project.status;
    document.getElementById('modalRole').textContent = project.role;

    // Set badge
    const modalBadge = document.getElementById('modalBadge');
    modalBadge.textContent = project.badgeText;
    modalBadge.className = 'modal__badge ' + project.badge;

    // Set tech tags
    const modalTech = document.getElementById('modalTech');
    modalTech.innerHTML = project.tech
        .map(t => `<span class="tech-tag">${t}</span>`)
        .join('');

    // Set action buttons
    const modalActions = document.getElementById('modalActions');
    let actionsHTML = '';

    if (project.repoUrl) {
        actionsHTML += `<a href="${project.repoUrl}" target="_blank" rel="noopener noreferrer" class="btn btn--small">Repository</a>`;
    } else {
        actionsHTML += `<span class="repo-unavailable">Repository belum ditambahkan</span>`;
    }

    if (project.demoUrl) {
        actionsHTML += `<a href="${project.demoUrl}" target="_blank" rel="noopener noreferrer" class="btn btn--small btn--primary">Live Demo</a>`;
    }

    modalActions.innerHTML = actionsHTML;

    // Show modal
    modalOverlay.classList.add('active');
    modalOverlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    // Focus the close button for accessibility
    setTimeout(() => {
        modalClose.focus();
    }, 100);
}

function closeModal() {
    modalOverlay.classList.remove('active');
    modalOverlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
}

// Detail button click events
detailBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const projectKey = btn.getAttribute('data-project');
        openModal(projectKey);
    });
});

// Close modal events
modalClose.addEventListener('click', closeModal);

modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
        closeModal();
    }
});

// Escape key to close modal
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        if (modalOverlay.classList.contains('active')) {
            closeModal();
        }
        // Also close mobile menu
        if (navMenu.classList.contains('active')) {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            navToggle.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
        }
    }
});

// ===== BACK TO TOP =====
function handleBackToTop() {
    if (window.scrollY > 400) {
        backToTop.classList.add('visible');
    } else {
        backToTop.classList.remove('visible');
    }
}

window.addEventListener('scroll', handleBackToTop);

backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ===== SCROLL REVEAL ANIMATION =====
function revealOnScroll() {
    const reveals = document.querySelectorAll('.reveal');
    const windowHeight = window.innerHeight;

    reveals.forEach(el => {
        const elementTop = el.getBoundingClientRect().top;
        const revealPoint = 100;

        if (elementTop < windowHeight - revealPoint) {
            el.classList.add('visible');
        }
    });
}

window.addEventListener('scroll', revealOnScroll);
window.addEventListener('load', revealOnScroll);

// ===== CONTACT FORM VALIDATION =====
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showError(inputId, errorId, message) {
    const input = document.getElementById(inputId);
    const error = document.getElementById(errorId);
    if (input) input.classList.add('error');
    if (error) error.textContent = message;
}

function clearError(inputId, errorId) {
    const input = document.getElementById(inputId);
    const error = document.getElementById(errorId);
    if (input) input.classList.remove('error');
    if (error) error.textContent = '';
}

if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        let isValid = true;

        const name = document.getElementById('contactName').value.trim();
        const email = document.getElementById('contactEmail').value.trim();
        const subject = document.getElementById('contactSubject').value.trim();
        const message = document.getElementById('contactMessage').value.trim();

        // Clear previous errors
        clearError('contactName', 'nameError');
        clearError('contactEmail', 'emailError');
        clearError('contactMessage', 'messageError');

        // Validate name
        if (!name) {
            showError('contactName', 'nameError', 'Nama wajib diisi.');
            isValid = false;
        } else if (name.length < 2) {
            showError('contactName', 'nameError', 'Nama minimal 2 karakter.');
            isValid = false;
        }

        // Validate email
        if (!email) {
            showError('contactEmail', 'emailError', 'Email wajib diisi.');
            isValid = false;
        } else if (!validateEmail(email)) {
            showError('contactEmail', 'emailError', 'Format email tidak valid.');
            isValid = false;
        }

        // Validate message
        if (!message) {
            showError('contactMessage', 'messageError', 'Pesan wajib diisi.');
            isValid = false;
        } else if (message.length < 10) {
            showError('contactMessage', 'messageError', 'Pesan minimal 10 karakter.');
            isValid = false;
        }

        if (isValid) {
            // Build mailto link
            const mailtoEmail = 'email@example.com'; // GANTI DENGAN EMAIL ANDA
            const mailtoSubject = encodeURIComponent(subject || 'Pesan dari Portofolio');
            const mailtoBody = encodeURIComponent(
                `Nama: ${name}\nEmail: ${email}\n\nPesan:\n${message}`
            );
            const mailtoLink = `mailto:${mailtoEmail}?subject=${mailtoSubject}&body=${mailtoBody}`;

            // Open email client
            window.location.href = mailtoLink;
        }
    });

    // Real-time validation clearing
    ['contactName', 'contactEmail', 'contactMessage'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', () => {
                const errorId = id.replace('contact', '').toLowerCase() + 'Error';
                clearError(id, errorId);
            });
        }
    });
}

// ===== FADE IN UP ANIMATION KEYFRAMES =====
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(styleSheet);

// ===== THROTTLE HELPER =====
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Optimize scroll listeners with throttle
const optimizedHandlers = () => {
    handleNavbarScroll();
    updateActiveNavLink();
    handleBackToTop();
    revealOnScroll();
};

// Replace individual scroll listeners with single throttled handler
window.removeEventListener('scroll', handleNavbarScroll);
window.removeEventListener('scroll', updateActiveNavLink);
window.removeEventListener('scroll', handleBackToTop);
window.removeEventListener('scroll', revealOnScroll);
window.addEventListener('scroll', throttle(optimizedHandlers, 16));

// Initial calls
document.addEventListener('DOMContentLoaded', () => {
    handleNavbarScroll();
    updateActiveNavLink();
    revealOnScroll();
});
